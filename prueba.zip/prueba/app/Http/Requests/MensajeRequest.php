<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MensajeRequest extends FormRequest{
    public function authorize(){
        return true;
    }

    public function messages(){
        return[
            'user_id.required'=>'¿Donde esta el destinatario?',
            'mensaje.required'=>'El cuerpo de la noticia es obligatorio',
            'mensaje.min'=>'Demasiado corto'
        ];
    }

    public function rules(){
        return[
            'user_id'=>'required',
            'mensaje'=>'required|min: 5'
        ];
    }
}