<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Mensaje;

class MensajeController extends Controller{
    public function inicio(){
    	$usuarios=count(User::all());
    	$mensajes=count(Mensaje::all());
    	return view('inicio',compact('usuarios','mensajes'));
    }
}