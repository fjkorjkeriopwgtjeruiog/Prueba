<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Mensaje;
use App\Http\Requests\MensajeRequest;

class MensajeController extends Controller{
    public function inicio(){
    	$usuarios=count(User::all());
    	$mensajes=count(Mensaje::all());
    	return view('inicio',compact('usuarios','mensajes'));
    }

    public function lista(){
    	$mensajes=Mensaje::all();
    	if(count($mensajes)>0)
	    	return view('lista',compact('mensajes'));
	    else
	    	return back()->with('message',['danger','¡Error! ¡No hay mensajes aún!']);
    }

    public function escribir(){
    	$usuarios=User::all();
    	if(count($usuarios)>0)
    		return view('formularios.introducir',compact('usuarios'));
    	else
    		return back()->with('message',['danger','¡Error! ¡No hay usuarios aún!']);
    }

    public function enviar(MensajeRequest $request){
    	$a=Mensaje::create($request->all());
    	return back()->with('message',['success','¡Mensaje enviado con exito!']);
    }
}