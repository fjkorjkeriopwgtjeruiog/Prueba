<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><h1><?php echo e(__('Envia un email a uno de nuestros usuarios')); ?></h1></div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('escrito')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="form-group row">
                                <label for="user_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Destinatario')); ?></label>

                                <div class="col-sm-6">
                                     <select name="user_id" class="form-control">
                                        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <option value="<?php echo e($usuario->id); ?>" <?php echo e(old('user_id')==$usuario->id ? 'selected' : ''); ?>><?php echo e($usuario->name); ?> (<?php echo e($usuario->email); ?>)</option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                               </div>
                            </div>

                            <div class="form-group row">
                                <label for="mensaje" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Mensaje')); ?></label>

                                <div class="col-md-6">
                                    <textarea id="mensaje" name="mensaje" placeholder="Escribe aquí el mensaje que enviaras"><?php echo e(old('mensaje')); ?></textarea>

                                    <?php if($errors->has('mensaje')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('mensaje')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Enviar Correo Electrónico')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prueba\resources\views/formularios/introducir.blade.php ENDPATH**/ ?>