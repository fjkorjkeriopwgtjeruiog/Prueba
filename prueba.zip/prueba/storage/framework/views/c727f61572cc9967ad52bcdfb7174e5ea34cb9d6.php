<?php
    $eficiencia="badge badge-info badge-cat";
    $secundo="badge badge-primary badge-cat";
?>

<!-- Mensajes enviados -->

<div class="card card-03">
    <div class="card-body">
        <h2 class="card-title"><b><i><u><?php echo e(__('Mensaje')); ?> <?php echo e($m->id); ?></u></i></b></h2>
        <table>
            <td>
                <span class="<?php echo e($eficiencia); ?>"><?php echo e(__('ID del destinatario:')); ?> <?php echo e($m->user_id); ?></span><br>
                <span class="<?php echo e($eficiencia); ?>"><?php echo e(__('Nombre del destinatario:')); ?> <?php echo e($m->user->name); ?></span><br>
                <span class="<?php echo e($eficiencia); ?>">Email: <?php echo e($m->user->email); ?></span><br><br>
                <center><span class="<?php echo e($secundo); ?>"><?php echo e(__('Mensaje enviado:')); ?></span></center>
                <span class="<?php echo e($secundo); ?>">"<?php echo e($m->mensaje); ?>"</span>
            </td>
        </table>
    </div>
</div><?php /**PATH C:\xampp\htdocs\prueba\resources\views/informador/mensajes.blade.php ENDPATH**/ ?>