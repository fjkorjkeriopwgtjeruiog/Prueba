<?php $__env->startSection('content'); ?>
	<center><b><i><u><font size="20">Bienvenido a la sección del correo electronico</font></u></i></b>
	<?php if($usuarios<2): ?>
		<?php if($usuarios==0): ?>
			<p>No hay usuarios por ahora</p>
		<?php else: ?>
			<p>Solo tenemos un usuario</p>
		<?php endif; ?>
	<?php else: ?>
		<p>Tenemos <?php echo e($usuarios); ?> usuarios
			<?php if($mensajes>0): ?>
				y <?php echo e($mensajes); ?> mensajes
			<?php endif; ?>
			.
		</p>
	<?php endif; ?>
	<?php if($usuarios>0): ?>
		<p><a href="<?php echo e(url('/llamar/')); ?>">Enviar un mensaje a un usuario</a></p>
		<?php if($mensajes>0): ?>
			<p><a href="<?php echo e(url('/leer/')); ?>">Ver la lista de mensajes enviados</a></p>
		<?php endif; ?>
	<?php endif; ?>
	</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prueba\resources\views/inicio.blade.php ENDPATH**/ ?>