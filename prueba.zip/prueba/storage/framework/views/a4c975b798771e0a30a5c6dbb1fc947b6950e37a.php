<?php $__env->startSection('content'); ?>
	<center><b><i><u><font size="20"><?php echo e(__('Bienvenido a la sección del correo electronico')); ?></font></u></i></b>
		<p>
		<?php if($usuarios==0): ?>
			<?php echo e(__('No hay usuarios por ahora')); ?>

		<?php elseif($usuarios==1): ?>
			<?php echo e(__('Solo tenemos un usuario')); ?>

		<?php else: ?>
			<?php echo e(__('Tenemos')); ?> <?php echo e($usuarios); ?> <?php echo e(__('usuarios')); ?>

		<?php endif; ?>

		<?php if($mensajes>1): ?>
			<?php echo e(__('y')); ?> <?php echo e($mensajes); ?> <?php echo e(__('mensajes')); ?>

		<?php elseif($mensajes==1): ?>
			<?php echo e(__('y un mensaje')); ?>

		<?php endif; ?>
		.
		</p>

		<?php if($usuarios>0): ?>
			<p><a href="<?php echo e(url('/llamar/')); ?>"><?php echo e(__('Enviar un mensaje a un usuario')); ?></a></p>
			<?php if($mensajes>0): ?>
				<p><a href="<?php echo e(url('/leer/')); ?>"><?php echo e(__('Ver la lista de mensajes enviados')); ?></a></p>
			<?php endif; ?>
		<?php endif; ?>
	</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prueba\resources\views/inicio.blade.php ENDPATH**/ ?>