@extends('layouts.app')

@section('content')
	<center><b><i><u><font size="20">Bienvenido a la sección del correo electronico</font></u></i></b>
	@if($usuarios<2)
		@if($usuarios==0)
			<p>No hay usuarios por ahora</p>
		@else
			<p>Solo tenemos un usuario</p>
		@endif
	@else
		<p>Tenemos {{$usuarios}} usuarios
			@if($mensajes>0)
				y {{$mensajes}} mensajes
			@endif
			.
		</p>
	@endif
	@if($usuarios>0)
		<p><a href="{{ url('/llamar/') }}">Enviar un mensaje a un usuario</a></p>
		@if($mensajes>0)
			<p><a href="{{ url('/leer/') }}">Ver la lista de mensajes enviados</a></p>
		@endif
	@endif
	</center>
@endsection