@extends('layouts.app')

@section('content')
	<center><b><i><u><font size="20">{{ __('Bienvenido a la sección del correo electronico') }}</font></u></i></b>
		<p>
		@if($usuarios==0)
			{{ __('No hay usuarios por ahora') }}
		@elseif($usuarios==1)
			{{ __('Solo tenemos un usuario') }}
		@else
			{{ __('Tenemos') }} {{$usuarios}} {{ __('usuarios') }}
		@endif

		@if($mensajes>1)
			{{ __('y') }} {{$mensajes}} {{ __('mensajes') }}
		@elseif($mensajes==1)
			{{ __('y un mensaje') }}
		@endif
		.
		</p>

		@if($usuarios>0)
			<p><a href="{{ url('/llamar/') }}">{{ __('Enviar un mensaje a un usuario') }}</a></p>
			@if($mensajes>0)
				<p><a href="{{ url('/leer/') }}">{{ __('Ver la lista de mensajes enviados') }}</a></p>
			@endif
		@endif
	</center>
@endsection