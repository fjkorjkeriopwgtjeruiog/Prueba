@extends('layouts.app')
@section('content')
<h1 class="text-center text-mute"><u>Lista de mensajes enviados:</u></h1>
    <div class="pl-5 pr-5">
        <div class="row justify-content-center">
            @forelse($mensajes as $m)
                @include('informador.mensajes')
            @empty
                <div class="alert alert-danger">
                    <h1 class="text-center">No existen mensajes aún.</h1>
                </div>
            @endforelse
        </div>
    </div>
@endsection