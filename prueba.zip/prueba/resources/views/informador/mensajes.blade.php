<?php
    $eficiencia="badge badge-info badge-cat";
    $secundo="badge badge-primary badge-cat";
?>

<!-- Mensajes enviados -->

<div class="card card-03">
    <div class="card-body">
        <h2 class="card-title"><b><i><u>{{ __('Mensaje') }} {{$m->id}}</u></i></b></h2>
        <table>
            <td>
                <span class="{{$eficiencia}}">{{ __('ID del destinatario:') }} {{ $m->user_id }}</span><br>
                <span class="{{$eficiencia}}">{{ __('Nombre del destinatario:') }} {{ $m->user->name }}</span><br>
                <span class="{{$eficiencia}}">Email: {{ $m->user->email }}</span><br><br>
                <center><span class="{{$secundo}}">{{ __('Mensaje enviado:') }}</span></center>
                <span class="{{$secundo}}">"{{ $m->mensaje }}"</span>
            </td>
        </table>
    </div>
</div>