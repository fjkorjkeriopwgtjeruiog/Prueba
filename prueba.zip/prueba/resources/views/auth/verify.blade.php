@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Verifica tu correo electronico') }}</div>

                <div class="card-body">
                    @if (session('resent'))
                        <div class="alert alert-success" role="alert">
                            {{ __('Se ha enviado un mensaje de verifiación a tu email.') }}
                        </div>
                    @endif

                    {{ __('Antes de nada, revisa tu email para ver si te ha llegado un email de verificación.') }}
                    {{ __('Si no recibiste el email') }}, <a href="{{ route('verification.resend') }}">{{ __('pulsa aquí para pedir otro.') }}</a>.
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
