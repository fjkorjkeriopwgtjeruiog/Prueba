<?php

Route::get('/','MensajeController@inicio');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
