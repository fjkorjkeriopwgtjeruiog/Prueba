<?php

Route::get('/','MensajeController@inicio');

Auth::routes();

Route::get('/llamar','MensajeController@escribir');
Route::post('/llamar','MensajeController@enviar')->name('escrito');

Route::get('/leer','MensajeController@lista');